# Re-export through package namespace.
from .exports import public_decode
