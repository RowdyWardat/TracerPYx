from mockdep.codec import decode_blob as _decoder

def public_decode(value):
    return _decoder(value)
