# TracerPyX Benchmark 2 — Call Graph & Reachability

A second, separate Python static-analysis test pack. This one emphasizes less-trivial call graphs:
- imported aliases and re-exports
- decorators and callbacks
- inheritance / overridden methods
- async call chains
- dead code and unused functions
- exception and feature-flag branches
- star imports and package-level exports

All vulnerable sinks are **inert local stubs**. They only return strings; no exploit payloads, network listeners, shell commands, or destructive actions are included.

## Run
No third-party dependencies are required.

```bash
python -m demo.main
```

Upload the complete extracted folder or ZIP to TracerPyX, run a full source/call-graph scan, then compare with `ground_truth/expected_results.json`.

## Important
This pack is a source-reachability benchmark, not a CVE database test. `VULN-SINK` labels identify mock dependency functions for call-path analysis. A scanner that requires known package advisories may not count these as dependency vulnerabilities; it should still be able to analyze the source call paths if it supports source-level sink rules.

## Expected classifications
See `ground_truth/expected_results.json`. Cases marked `UNCERTAIN_OR_REACHABLE_IF_MODELED` are deliberately capability-sensitive: report `REACHABLE` only when the analyzer can establish the callback/dispatch path; otherwise report `UNCERTAIN` with a reason.
