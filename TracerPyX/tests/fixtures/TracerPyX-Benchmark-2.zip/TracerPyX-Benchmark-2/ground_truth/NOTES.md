# Ground-truth notes

Some cases are intentionally analyzer-capability-sensitive. Do not treat a capability-sensitive expected value as a universal binary answer.

- Decorators: resolve wrapper-to-original function relationships.
- Callbacks: track function objects passed as values.
- Inheritance: resolve the concrete class at the call site.
- Feature flag: constant propagation can prove the branch inactive in this configuration. A conservative analyzer should state its assumptions.
- Dynamic getattr and runtime registry: uncertainty is preferable to an unsupported certainty claim.
- Dormant functions: distinguish a sink call inside a definition from a call path from an entry point.
