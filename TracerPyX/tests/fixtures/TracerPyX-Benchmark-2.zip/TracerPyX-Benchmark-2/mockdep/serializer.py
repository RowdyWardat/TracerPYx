def load_compat(data):
    # VULN-SINK: B2-T05, B2-T09
    return "loaded:" + str(data)
