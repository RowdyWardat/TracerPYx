def old_convert(value):
    # VULN-SINK: B2-T10, B2-T13
    return "converted:" + str(value)
