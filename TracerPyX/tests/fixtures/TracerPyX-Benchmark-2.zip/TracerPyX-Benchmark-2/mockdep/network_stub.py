def parse_response(response):
    # VULN-SINK: B2-T06
    return "parsed:" + str(response)
