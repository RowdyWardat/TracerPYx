def decode_blob(value):
    # VULN-SINK: B2-T01, B2-T02, B2-T03, B2-T08
    return "decoded:" + str(value)
