def inspect_member(name):
    # VULN-SINK: B2-T07, B2-T12
    return "inspected:" + str(name)
