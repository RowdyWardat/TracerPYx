def render_legacy(template):
    # VULN-SINK: B2-T04, B2-T11
    return "rendered:" + str(template)
