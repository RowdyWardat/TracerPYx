from demo.direct import run_direct
from demo.alias_chain import run_alias_chain
from demo.callback_case import run_callback
from demo.async_case import run_async_case
from demo.inheritance_case import run_inheritance

def main():
    print(run_direct())
    print(run_alias_chain())
    print(run_callback())
    print(run_inheritance())
    # async_case is intentionally available as a separate entry point.
    # dormant and unreferenced fixtures are intentionally not called.

if __name__ == "__main__":
    main()
