from mockdep.codec import decode_blob

def apply_callback(callback, value):
    return callback(value)

def run_callback():
    # B2-T08: callback passed as a first-class function.
    return apply_callback(decode_blob, "callback sample")
