from mockdep.archive import inspect_member
from mockdep.legacy import old_convert

def never_called_archive_job():
    # B2-T04: sink in an unreferenced function.
    return inspect_member("unused.bin")

def never_called_converter():
    # B2-T10: another dormant sink call.
    return old_convert("unused")
