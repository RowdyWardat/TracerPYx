from mockdep.template import render_legacy

def audit_wrapper(fn):
    def wrapped(value):
        return fn(value)
    return wrapped

@audit_wrapper
def decorated_render(value):
    return render_legacy(value)

def run_decorated():
    # B2-T03: decorator/wrapper path to sink.
    return decorated_render("hello")
