_REGISTRY = {}

def register(name, callback):
    _REGISTRY[name] = callback

def execute_registered(name, value):
    # B2-T12: callback target depends on runtime registration.
    return _REGISTRY[name](value)
