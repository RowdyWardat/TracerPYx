from mockdep.template import render_legacy

def run_exception_path(value):
    try:
        if value == "trigger":
            raise ValueError("local test branch")
    except ValueError:
        # B2-T11: exception handler reaches sink.
        return render_legacy("recovery template")
    return "normal path"
