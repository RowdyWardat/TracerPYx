from compat import public_decode as decode

def run_alias_chain():
    # B2-T02: entry -> re-export -> alias -> sink.
    return decode("alias sample")
