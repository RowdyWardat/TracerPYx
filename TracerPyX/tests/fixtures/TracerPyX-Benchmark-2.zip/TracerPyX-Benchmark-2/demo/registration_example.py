from mockdep.archive import inspect_member
from demo.registry_case import register

def install_archive_plugin():
    register("archive", inspect_member)
