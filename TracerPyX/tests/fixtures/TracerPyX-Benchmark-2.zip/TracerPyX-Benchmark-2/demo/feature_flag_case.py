from mockdep.serializer import load_compat

FEATURE_ENABLED = False

def run_feature_flag():
    # B2-T09: statically false feature flag. A path-insensitive analyzer may
    # report potentially reachable; a constant-propagating analyzer may prove
    # this branch dead in this configuration.
    if FEATURE_ENABLED:
        return load_compat("feature data")
    return "feature disabled"
