from mockdep.codec import decode_blob

def run_direct():
    # B2-T01: direct sink call.
    return decode_blob("sample")
