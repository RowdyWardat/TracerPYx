from mockdep.archive import inspect_member

class BaseProcessor:
    def process(self, item):
        return "base:" + item

class ArchiveProcessor(BaseProcessor):
    def process(self, item):
        # B2-T07: overridden method reaches sink.
        return inspect_member(item)

def run_inheritance():
    processor = ArchiveProcessor()
    return processor.process("document.txt")
