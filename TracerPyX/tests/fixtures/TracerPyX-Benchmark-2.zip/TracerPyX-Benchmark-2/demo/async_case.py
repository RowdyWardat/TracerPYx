from mockdep.network_stub import parse_response

async def fetch_stub():
    return "local response"

async def process_response():
    response = await fetch_stub()
    # B2-T06: async function calls marked sink.
    return parse_response(response)

async def run_async_case():
    return await process_response()
