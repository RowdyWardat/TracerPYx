from mockdep.legacy import *

def run_star_import():
    # B2-T13: star-imported symbol; sink is reached if symbol resolution works.
    return old_convert("star import")
