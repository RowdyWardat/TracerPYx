import mockdep.serializer as serializer

def dispatch(name, value):
    # B2-T05: name is runtime-controlled; getattr target is not statically fixed.
    function = getattr(serializer, name)
    return function(value)
