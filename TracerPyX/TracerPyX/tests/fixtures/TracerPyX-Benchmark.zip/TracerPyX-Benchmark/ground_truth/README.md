# Ground truth notes

The JSON file records intended outcomes and expected call paths. T08 is deliberately capability-sensitive: constant propagation should resolve the `getattr` target; if TracerPyX does not support that, `UNCERTAIN` with an explanation is acceptable.

T02 and T04 are negative reachability cases. Do not confuse the presence of an import or function definition with a reachable call path.

T07 is a runtime plugin case. Static analysis may identify a possible path from `run_plugin` to the plugin implementation only if it models registration and the selected plugin. Otherwise, uncertainty is the expected safe result.
