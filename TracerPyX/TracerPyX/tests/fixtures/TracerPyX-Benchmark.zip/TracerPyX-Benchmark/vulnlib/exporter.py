def export_legacy(value: str):
    # VULN-SINK: T04. No reachable caller from benchmark entry points.
    return f"legacy-export:{value}"
