def parse_document(value: str):
    # VULN-SINK: T01, T03, T10 and preview path. Inert benchmark stub.
    return f"parsed:{value}"
