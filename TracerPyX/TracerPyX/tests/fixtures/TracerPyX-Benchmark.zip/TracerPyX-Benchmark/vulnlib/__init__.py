"""Local inert stand-in for a dependency with marked vulnerable sinks."""
__version__ = "0.1.0-benchmark"
