def inspect_archive(name: str):
    # VULN-SINK: T09. Inert benchmark stub.
    return f"inspected:{name}"
