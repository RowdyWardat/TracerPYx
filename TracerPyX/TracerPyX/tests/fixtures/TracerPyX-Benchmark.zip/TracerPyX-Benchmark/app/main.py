"""Benign benchmark entry point. Run with: python -m app.main"""
from app.routes import handle_preview
from app.direct_case import run_direct
from app.transitive_case import run_transitive
from app.wrapper_case import run_wrapper
from app.conditional_case import run_conditional

def main():
    print(run_direct())
    print(run_transitive())
    print(run_wrapper())
    print(run_conditional(enabled=False))
    # T04's legacy_admin_export handler is intentionally not registered/called.
    # Dynamic/plugin fixtures are intentionally not invoked by this demo.
    print(handle_preview("sample"))

if __name__ == "__main__":
    main()
