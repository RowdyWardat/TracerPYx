from services.report_service import build_report

def run_transitive():
    # T03: entry -> service -> helper -> dependency sink.
    return build_report("quarterly")
