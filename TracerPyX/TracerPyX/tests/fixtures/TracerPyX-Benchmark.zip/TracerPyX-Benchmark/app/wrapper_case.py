from services.safe_wrapper import normalize_and_parse

def run_wrapper():
    # T10: wrapper call eventually reaches the marked dependency sink.
    return normalize_and_parse("safe wrapper sample")
