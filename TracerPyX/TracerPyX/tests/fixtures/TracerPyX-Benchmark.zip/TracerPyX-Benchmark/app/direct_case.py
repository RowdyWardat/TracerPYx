from vulnlib.parser import parse_document

def run_direct():
    # T01: direct application-to-dependency call.
    return parse_document("safe sample")
