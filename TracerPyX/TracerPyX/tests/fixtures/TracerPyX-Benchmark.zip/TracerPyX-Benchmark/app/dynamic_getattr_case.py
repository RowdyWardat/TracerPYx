import vulnlib.parser as parser_module

def dispatch_by_name(method_name: str, value: str):
    # T05: dynamic attribute lookup. The caller controls method_name at runtime.
    target = getattr(parser_module, method_name)
    return target(value)
