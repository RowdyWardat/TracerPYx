from services.preview_service import preview_document

def handle_preview(document: str):
    return preview_document(document)

def legacy_admin_export(document: str):
    # T04: vulnerable sink is behind this handler, but this function is not
    # registered as a route and has no callers in the benchmark entry graph.
    from vulnlib.exporter import export_legacy
    return export_legacy(document)
