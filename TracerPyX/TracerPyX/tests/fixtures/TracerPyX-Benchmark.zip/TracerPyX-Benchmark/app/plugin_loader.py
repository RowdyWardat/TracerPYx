_PLUGIN_REGISTRY = {}

def register_plugin(name, module):
    _PLUGIN_REGISTRY[name] = module

def run_plugin(name, function_name, value):
    # T07: runtime registry lookup followed by dynamic attribute resolution.
    plugin = _PLUGIN_REGISTRY[name]
    target = getattr(plugin, function_name)
    return target(value)
