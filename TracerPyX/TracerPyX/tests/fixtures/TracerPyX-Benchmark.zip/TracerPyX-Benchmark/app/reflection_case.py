from vulnlib import parser

def invoke_reflectively(value: str):
    # T08: reflective lookup using a constant name. An analyzer may resolve this
    # to REACHABLE; otherwise it should explain its uncertainty.
    operation = getattr(parser, "parse_document")
    return operation(value)
