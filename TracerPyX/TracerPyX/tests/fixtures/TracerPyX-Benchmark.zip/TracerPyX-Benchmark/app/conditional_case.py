from vulnlib.archive import inspect_archive

def run_conditional(enabled: bool):
    # T09: potentially reachable when enabled is True.
    if enabled:
        return inspect_archive("sample.zip")
    return "condition false; sink not called on this execution"
