import importlib

def load_and_run(module_name: str, function_name: str, value: str):
    # T06: both module and function are resolved dynamically.
    module = importlib.import_module(module_name)
    target = getattr(module, function_name)
    return target(value)
