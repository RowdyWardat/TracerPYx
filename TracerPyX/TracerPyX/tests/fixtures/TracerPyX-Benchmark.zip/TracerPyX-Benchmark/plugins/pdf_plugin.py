from vulnlib.parser import parse_document

def process(value: str):
    # T07 plugin implementation reaches a marked sink if registered and invoked.
    return parse_document(value)
