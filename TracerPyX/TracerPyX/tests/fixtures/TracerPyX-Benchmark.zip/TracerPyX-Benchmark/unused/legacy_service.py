from vulnlib.archive import inspect_archive

def old_import_job(name: str):
    # T02: function imports/calls a marked sink but is never called anywhere.
    return inspect_archive(name)
