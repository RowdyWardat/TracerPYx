# TracerPyX-Benchmark

A small, self-contained Python source-code benchmark for testing **dependency-function reachability analysis**.

This project is deliberately designed as a static-analysis fixture. It uses a local mock dependency (`vulnlib`) with clearly marked vulnerable sinks. It does **not** install known-vulnerable third-party packages, expose a network service, or execute exploits.

## Quick start

1. Extract the ZIP.
2. Upload the entire `TracerPyX-Benchmark` folder or ZIP to TracerPyX.
3. Run source analysis and dependency/call-graph analysis.
4. Compare findings with `ground_truth/expected_results.json`.
5. Check whether the tool reports evidence paths, source locations, confidence, and limitations.

Optional: run the benign demonstration:

```bash
python -m app.main
```

The demo only prints messages. It does not execute dangerous operations.

## Test cases

| ID | Scenario | Expected classification |
|---|---|---|
| T01 | Direct call to a vulnerable dependency function | REACHABLE |
| T02 | Vulnerable function exists but is never called | NOT_REACHABLE |
| T03 | Transitive call through multiple modules | REACHABLE |
| T04 | Vulnerable function behind an unreferenced route handler | NOT_REACHABLE |
| T05 | `getattr()`-based dispatch | UNCERTAIN unless the analyzer resolves the constant attribute |
| T06 | Dynamic module import | UNCERTAIN unless the analyzer resolves the module name |
| T07 | Plugin registry / plugin dispatch | UNCERTAIN unless plugin registration and dispatch are modeled |
| T08 | Reflection-like invocation through a wrapper | UNCERTAIN or REACHABLE if resolved |
| T09 | Conditional call | REACHABLE (possible path); report condition/path sensitivity |
| T10 | Wrapper function calls vulnerable sink | REACHABLE |

## Ground-truth interpretation

- **REACHABLE**: a statically visible application call path reaches the marked sink.
- **NOT_REACHABLE**: no call path exists from the benchmark entry points in this fixture.
- **UNCERTAIN**: execution depends on dynamic resolution or runtime registration. A sound analyzer should explain why it cannot prove either outcome.
- For T09, a call guarded by a runtime condition is still potentially reachable. It should not be reported as definitely unreachable merely because the condition is not known at scan time.

The mock vulnerable functions are inert: they only return strings. The `VULN-SINK` comments are labels for benchmark matching, not exploit code.

## Suggested evaluation

For each case, record:
- classification
- vulnerable function and file/line
- complete call path (when known)
- confidence / uncertainty explanation
- whether the analyzer distinguishes package presence from actual call reachability
- suggested remediation or upgrade guidance (the mock package has no real CVE)

## Important

This benchmark tests source-level call reachability. It is not a substitute for dependency vulnerability databases, package-version/SBOM scanning, runtime testing, or security review.
