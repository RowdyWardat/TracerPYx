from vulnlib.parser import parse_document

def render_report(period: str):
    return parse_document("report:" + period)
