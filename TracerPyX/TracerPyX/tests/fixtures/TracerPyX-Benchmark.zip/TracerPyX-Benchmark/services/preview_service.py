from vulnlib.parser import parse_document

def preview_document(document: str):
    return parse_document(document)
