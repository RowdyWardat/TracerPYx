from services.report_helpers import render_report

def build_report(period: str):
    return render_report(period)
