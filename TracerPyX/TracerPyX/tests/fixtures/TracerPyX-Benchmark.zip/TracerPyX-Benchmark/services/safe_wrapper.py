from vulnlib.parser import parse_document

def normalize_and_parse(value: str):
    cleaned = value.strip()
    return parse_document(cleaned)
